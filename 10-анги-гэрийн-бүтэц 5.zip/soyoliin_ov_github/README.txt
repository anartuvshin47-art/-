СОЁЛЫН ӨВ — GitHub Pages-д байршуулах багц

Энэ хавтасны 3 файлыг GitHub repository-ийн үндсэн түвшинд байршуулна:
- index.html
- zolzaya.jpg
- aisullu.jpg

GitHub дээр repository үүсгэхдээ Public сонгоно.
Дараа нь Settings > Pages > Build and deployment > Deploy from a branch > main > /(root) > Save.
Хэдэн минутын дараа https://USERNAME.github.io/REPOSITORY/ холбоос үүснэ.

Зураг ба нэрийн тохирол, гишүүн тус бүрийн үүрэг, бодит эх сурвалжийн жагсаалт одоогоор хэрэглэгчээр баталгаажуулах шаардлагатай.
